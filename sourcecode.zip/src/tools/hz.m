function dt = hz(x);
dt = 1/x;
end


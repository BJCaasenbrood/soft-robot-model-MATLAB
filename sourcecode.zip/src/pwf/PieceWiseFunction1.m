function S = PieceWiseFunction1(~,~)
    S = eye(3);
end